/* Page access for the static demo
   Admin pages need sessionStorage archnexAdmin
   Tracker needs sessionStorage archnexClient
   Logout clears the matching key
*/

(function () {
  var path = (location.pathname || location.href || "").replace(/\\/g, "/").toLowerCase();
  var parts = path.split("/").filter(function (p) { return p && p.indexOf(":") === -1; });
  var last = (parts[parts.length - 1] || "index").replace(".html", "").split("?")[0];
  var isAdmin = path.indexOf("/admin") !== -1;
  var isLogin = last === "login" || last === "login.html";

  if (isAdmin && !isLogin && sessionStorage.getItem("archnexAdmin") !== "1") {
    location.replace("login.html");
    return;
  }

  if (!isAdmin && last === "tracker" && sessionStorage.getItem("archnexClient") !== "1") {
    sessionStorage.setItem("archnexNext", "tracker.html");
    location.replace("login.html");
    return;
  }

  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("[data-logout]").forEach(function (link) {
      link.addEventListener("click", function (e) {
        e.preventDefault();
        sessionStorage.removeItem("archnexAdmin");
        sessionStorage.removeItem("archnexClient");
        location.href = link.getAttribute("href") || "login.html";
      });
    });

    var loginBtn = document.querySelector("[data-login-btn]");
    if (loginBtn && sessionStorage.getItem("archnexClient") === "1") {
      loginBtn.textContent = "Log out";
      loginBtn.addEventListener("click", function (e) {
        e.preventDefault();
        sessionStorage.removeItem("archnexClient");
        location.href = "index.html";
      });
    }
  });
})();
