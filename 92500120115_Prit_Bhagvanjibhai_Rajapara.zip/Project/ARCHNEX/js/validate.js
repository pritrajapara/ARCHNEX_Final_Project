/* JS Validation for ARCHNEX
   Fig 1.1 All fields are required
   Fig 1.2 Password length (minimum 8)
   Fig 1.3 Email pattern
   Fig 1.4 Password pattern (upper, lower, number, special)
   Fig 1.5 Phone number pattern (10 digit Indian mobile)
*/

(function () {
  var EMAIL_RE = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
  var PHONE_RE = /^[6-9]\d{9}$/;
  var PASS_RE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#^_\-]).{8,}$/;
  var DEMO_CLIENT = { email: "user@gmail.com", password: "Home@1234", name: "Sample User" };

  function loadUsers() {
    try {
      return JSON.parse(localStorage.getItem("archnexUsers") || "[]");
    } catch (e) {
      return [];
    }
  }

  function saveUsers(list) {
    localStorage.setItem("archnexUsers", JSON.stringify(list));
  }

  function errBox(input) {
    var id = input.id ? input.id + "Err" : "";
    var box = id ? document.getElementById(id) : null;
    if (!box) {
      box = input.parentNode.querySelector(".error-text");
    }
    return box;
  }

  function show(input, msg) {
    input.classList.add("is-invalid");
    var box = errBox(input);
    if (box) {
      box.textContent = msg;
      box.style.display = "block";
    }
  }

  function clear(input) {
    input.classList.remove("is-invalid");
    var box = errBox(input);
    if (box) {
      box.textContent = "";
      box.style.display = "none";
    }
  }

  function value(input) {
    return (input.value || "").trim();
  }

  function checkOne(input) {
    var rules = (input.getAttribute("data-validate") || "").split("|");
    var val = value(input);
    clear(input);

    if (rules.indexOf("required") !== -1 && val === "") {
      show(input, "This field is required.");
      return false;
    }
    if (val === "") return true;

    if (rules.indexOf("email") !== -1 && !EMAIL_RE.test(val)) {
      show(input, "Enter a valid email address (example: name@gmail.com).");
      return false;
    }
    if (rules.indexOf("phone") !== -1 && !PHONE_RE.test(val)) {
      show(input, "Enter a valid 10-digit mobile number starting with 6-9.");
      return false;
    }
    if (rules.indexOf("passwordLength") !== -1 && val.length < 8) {
      show(input, "Password must be at least 8 characters long.");
      return false;
    }
    if (rules.indexOf("password") !== -1 && !PASS_RE.test(val)) {
      show(input, "Password must include uppercase, lowercase, number and special character.");
      return false;
    }
    if (rules.indexOf("name") !== -1 && val.length < 3) {
      show(input, "Please enter your full name.");
      return false;
    }
    if (rules.indexOf("match") !== -1) {
      var other = document.getElementById(input.getAttribute("data-match"));
      if (other && value(other) !== val) {
        show(input, "Passwords do not match.");
        return false;
      }
    }
    return true;
  }

  function bindForm(form) {
    var fields = form.querySelectorAll("[data-validate]");
    fields.forEach(function (field) {
      field.addEventListener("blur", function () { checkOne(field); });
      field.addEventListener("input", function () {
        if (field.classList.contains("is-invalid")) checkOne(field);
      });
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var ok = true;
      fields.forEach(function (field) {
        if (!checkOne(field)) ok = false;
      });
      if (!ok) return;

      var role = form.getAttribute("data-role");

      if (role === "admin-login") {
        var mail = value(document.getElementById("aEmail"));
        var phone = value(document.getElementById("aPhone"));
        var pass = value(document.getElementById("aPass"));
        var confirmPass = value(document.getElementById("aPass2"));

        if (mail.toLowerCase() !== "admin@archnex.in" ||
            phone !== "9876544120" ||
            pass !== "Admin@123" ||
            confirmPass !== pass) {
          show(document.getElementById("aPass"), "Admin details do not match. Check your email, phone number and password.");
          return;
        }
        sessionStorage.setItem("archnexAdmin", "1");
        window.location.href = "dashboard.html";
        return;
      }

      if (role === "client-login") {
        var cMail = value(document.getElementById("loginEmail"));
        var cPass = value(document.getElementById("loginPass"));
        var users = loadUsers();
        var found = users.some(function (u) {
          return u.email.toLowerCase() === cMail.toLowerCase() && u.password === cPass;
        });
        var demo = cMail.toLowerCase() === DEMO_CLIENT.email && cPass === DEMO_CLIENT.password;
        if (!found && !demo) {
          show(document.getElementById("loginPass"), "Wrong email or password. Try user@gmail.com / Home@1234");
          return;
        }
        sessionStorage.setItem("archnexClient", "1");
        var next = sessionStorage.getItem("archnexNext") || "tracker.html";
        sessionStorage.removeItem("archnexNext");
        window.location.href = next;
        return;
      }

      if (role === "client-register") {
        var list = loadUsers();
        list.push({
          name: value(document.getElementById("regName")),
          email: value(document.getElementById("regEmail")),
          phone: value(document.getElementById("regPhone")),
          password: value(document.getElementById("regPass"))
        });
        saveUsers(list);
      }

      form.dispatchEvent(new CustomEvent("archnexvalid", { bubbles: true }));

      var okBox = form.querySelector(".ok-box");
      if (okBox) {
        okBox.style.display = "block";
        okBox.textContent = form.getAttribute("data-success") || "Submitted successfully.";
      }
      if (form.getAttribute("data-keep") !== "1") {
        form.reset();
        fields.forEach(clear);
      }
    });
  }

  document.querySelectorAll("form.js-validate").forEach(bindForm);
  window.ArchnexValidate = { checkOne: checkOne };
})();
