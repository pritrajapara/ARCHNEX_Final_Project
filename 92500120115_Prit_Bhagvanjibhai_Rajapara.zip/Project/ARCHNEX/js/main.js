/* Small helpers: year, design filters, estimator math, request chips */

document.querySelectorAll("[data-year]").forEach(function (el) {
  el.textContent = new Date().getFullYear();
});

/* Explore Designs — filter + search */
(function () {
  var grid = document.getElementById("designGrid");
  if (!grid) return;
  var cards = Array.prototype.slice.call(grid.querySelectorAll(".design-item"));
  var search = document.getElementById("designSearch");
  var styleF = document.getElementById("filterStyle");
  var budgetF = document.getElementById("filterBudget");
  var roomF = document.getElementById("filterRooms");
  var areaF = document.getElementById("filterArea");
  var sortF = document.getElementById("filterSort");
  var count = document.getElementById("designCount");

  function apply() {
    var q = (search.value || "").toLowerCase();
    var shown = [];
    cards.forEach(function (card) {
      var ok = true;
      if (q && card.dataset.title.toLowerCase().indexOf(q) === -1) ok = false;
      if (styleF.value && card.dataset.style !== styleF.value) ok = false;
      if (budgetF.value && card.dataset.budget !== budgetF.value) ok = false;
      if (roomF.value && card.dataset.rooms !== roomF.value) ok = false;
      if (areaF.value && card.dataset.area !== areaF.value) ok = false;
      card.style.display = ok ? "" : "none";
      if (ok) shown.push(card);
    });
    if (sortF.value === "price-low") {
      shown.sort(function (a, b) { return Number(a.dataset.price) - Number(b.dataset.price); });
    } else if (sortF.value === "price-high") {
      shown.sort(function (a, b) { return Number(b.dataset.price) - Number(a.dataset.price); });
    }
    shown.forEach(function (c) { grid.appendChild(c); });
    if (count) count.textContent = shown.length + " plans";
  }

  [search, styleF, budgetF, roomF, areaF, sortF].forEach(function (el) {
    if (!el) return;
    el.addEventListener("input", apply);
    el.addEventListener("change", apply);
  });
  apply();
})();

/* Cost estimator — live range, always above ₹60 L */
(function () {
  var form = document.getElementById("estimatorForm");
  if (!form) return;

  var rates = { villa: 4200, apartment: 3900, bungalow: 4550, interior: 3750, landscape: 4100 };
  var finishMul = { standard: 1, premium: 1.22, teak: 1.48 };
  var furnishMul = { no: 1, yes: 1.18 };

  function lakhs(n) {
    return "₹ " + (n / 100000).toFixed(1) + "L";
  }

  function calc() {
    var type = document.getElementById("estType").value || "villa";
    var area = Number(document.getElementById("estArea").value) || 0;
    var finish = document.getElementById("estMat").value || "premium";
    var furnish = document.getElementById("estPack").value || "yes";
    var base = area * (rates[type] || 4000) * (finishMul[finish] || 1) * (furnishMul[furnish] || 1);
    if (base < 6100000) base = 6100000 + area * 80;
    var civil = base * 0.7;
    var wood = base * 0.2;
    var cont = base * 0.1;
    var low = base * 0.92;
    var high = base * 1.16;
    document.getElementById("costCivil").textContent = lakhs(civil);
    document.getElementById("costWood").textContent = lakhs(wood);
    document.getElementById("costCont").textContent = lakhs(cont);
    document.getElementById("costRange").textContent = lakhs(low) + " – " + lakhs(high);
  }

  ["estType", "estArea", "estPack", "estMat"].forEach(function (id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("input", calc);
    el.addEventListener("change", calc);
  });
  calc();
})();

/* Consultation summary mirror */
(function () {
  var map = [
    ["cName", "sumName"],
    ["cDate", "sumDate"],
    ["cTime", "sumTime"],
    ["cType", "sumType"]
  ];
  map.forEach(function (pair) {
    var src = document.getElementById(pair[0]);
    var dest = document.getElementById(pair[1]);
    if (!src || !dest) return;
    src.addEventListener("input", function () {
      dest.textContent = src.value || "—";
    });
    src.addEventListener("change", function () {
      dest.textContent = src.value || "—";
    });
  });
})();

/* Admin request filter */
(function () {
  var btns = document.querySelectorAll("[data-req-filter]");
  if (!btns.length) return;
  btns.forEach(function (btn) {
    btn.addEventListener("click", function () {
      btns.forEach(function (b) { b.classList.remove("active"); });
      btn.classList.add("active");
      var f = btn.getAttribute("data-req-filter");
      document.querySelectorAll("#reqTable tbody tr").forEach(function (row) {
        row.style.display = (f === "all" || row.dataset.status === f) ? "" : "none";
      });
    });
  });
})();

/* Consultation: block past dates */
(function () {
  var d = document.getElementById("cDate");
  if (d) d.min = new Date().toISOString().slice(0, 10);
})();

/* Admin table search */
document.querySelectorAll("[data-table-search]").forEach(function (input) {
  input.addEventListener("input", function () {
    var table = document.querySelector(input.getAttribute("data-table-search"));
    if (!table) return;
    var q = (input.value || "").toLowerCase();
    table.querySelectorAll("tbody tr").forEach(function (row) {
      row.style.display = row.textContent.toLowerCase().indexOf(q) === -1 ? "none" : "";
    });
  });
});

/* View row -> fill detail card */
document.querySelectorAll("[data-view-table]").forEach(function (table) {
  table.addEventListener("click", function (e) {
    var btn = e.target.closest(".js-view");
    if (!btn) return;
    var row = btn.closest("tr");
    var box = document.getElementById(table.getAttribute("data-view-table"));
    if (!row || !box) return;
    var cells = row.querySelectorAll("td");
    var html = "";
    var heads = table.querySelectorAll("thead th");
    for (var i = 0; i < cells.length - 1; i++) {
      html += "<div class='row-line'><span>" + heads[i].textContent + "</span><span>" + cells[i].innerText + "</span></div>";
    }
    box.innerHTML = html || row.innerText;
    table.querySelectorAll("tr").forEach(function (r) { r.classList.remove("is-picked"); });
    row.classList.add("is-picked");
  });
});

/* Add user row after a valid submit */
(function () {
  var form = document.getElementById("userForm");
  var table = document.querySelector("#userTable tbody");
  if (!form || !table) return;
  form.addEventListener("archnexvalid", function () {
    var n = table.querySelectorAll("tr").length + 1;
    var id = "U" + String(n).padStart(3, "0");
    var name = document.getElementById("uName").value;
    var email = document.getElementById("uEmail").value;
    var phone = document.getElementById("uPhone").value;
    var tr = document.createElement("tr");
    tr.innerHTML = "<td>" + id + "</td><td>" + name + "</td><td>" + email + "</td><td>" + phone + "</td><td>Active</td><td><button type='button' class='btn btn-sm btn-ghost js-view'>View</button></td>";
    table.appendChild(tr);
  });
})();

/* Add design card after a valid submit */
(function () {
  var form = document.getElementById("designForm");
  var grid = document.getElementById("adminDesignGrid");
  if (!form || !grid) return;
  form.addEventListener("archnexvalid", function () {
    var title = document.getElementById("dTitle").value;
    var col = document.createElement("div");
    col.className = "col-md-4";
    col.innerHTML = "<article class='tool-card design-card'><img src='https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=700&q=80' alt=''><div class='pad'><strong></strong><div class='small text-muted'>Draft · just added</div></div></article>";
    col.querySelector("strong").textContent = title;
    grid.appendChild(col);
    var badge = document.getElementById("designLiveCount");
    if (badge) badge.textContent = grid.children.length + " on this screen";
  });
})();

/* Project row select + save status into the table */
(function () {
  var btn = document.getElementById("saveProjectStatus");
  var table = document.getElementById("projectTable");
  var label = document.getElementById("selectedProject");
  if (!btn || !table) return;
  var selected = table.querySelector("tbody tr");

  table.querySelectorAll("tbody tr").forEach(function (row) {
    row.style.cursor = "pointer";
    row.addEventListener("click", function () {
      table.querySelectorAll("tr").forEach(function (r) { r.classList.remove("is-picked"); });
      row.classList.add("is-picked");
      selected = row;
      if (label) label.textContent = row.cells[0].textContent + " · " + row.cells[1].textContent;
    });
  });
  if (selected) selected.classList.add("is-picked");

  btn.addEventListener("click", function () {
    var radio = document.querySelector("input[name='st']:checked");
    if (selected && radio) {
      selected.cells[4].textContent = radio.value;
    }
    var box = document.getElementById("projectSaved");
    if (box) box.style.display = "block";
  });
})();
